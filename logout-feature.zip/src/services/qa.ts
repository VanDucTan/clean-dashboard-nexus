import { qaApi, handleApiError, ApiResponse } from '@/lib/axios';

export interface Question {
  id: string;
  title: string;
  content: string;
  type: string;
  status: 'pending' | 'answered' | 'closed';
  authorId: string;
  createdAt: string;
  updatedAt: string;
}

export interface Answer {
  id: string;
  questionId: string;
  content: string;
  authorId: string;
  createdAt: string;
  updatedAt: string;
}

export interface QuestionType {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

// Questions
export const getQuestions = async (): Promise<Question[]> => {
  try {
    const response = await qaApi.get<ApiResponse<Question[]>>('/questions');
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const getQuestion = async (id: string): Promise<Question> => {
  try {
    const response = await qaApi.get<ApiResponse<Question>>(`/questions/${id}`);
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const createQuestion = async (data: { title: string; content: string; type: string }): Promise<Question> => {
  try {
    const response = await qaApi.post<ApiResponse<Question>>('/questions', data);
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const updateQuestionStatus = async (id: string, status: Question['status']): Promise<Question> => {
  try {
    const response = await qaApi.patch<ApiResponse<Question>>(`/questions/${id}/status`, { status });
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

// Answers
export const getQuestionAnswers = async (questionId: string): Promise<Answer[]> => {
  try {
    const response = await qaApi.get<ApiResponse<Answer[]>>(`/questions/${questionId}/answers`);
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const createAnswer = async (questionId: string, content: string): Promise<Answer> => {
  try {
    const response = await qaApi.post<ApiResponse<Answer>>(`/questions/${questionId}/answers`, { content });
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

// Question Types
export const getQuestionTypes = async (): Promise<QuestionType[]> => {
  try {
    const response = await qaApi.get<ApiResponse<QuestionType[]>>('/types');
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const createQuestionType = async (data: { name: string; description?: string }): Promise<QuestionType> => {
  try {
    const response = await qaApi.post<ApiResponse<QuestionType>>('/types', data);
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
}; 