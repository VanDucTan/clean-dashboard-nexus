import { recruitmentApi, handleApiError, ApiResponse } from '@/lib/axios';

export interface Application {
  id: string;
  candidateName: string;
  position: string;
  status: 'pending' | 'reviewing' | 'interviewed' | 'accepted' | 'rejected';
  createdAt: string;
  updatedAt: string;
}

export interface Interview {
  id: string;
  applicationId: string;
  interviewerId: string;
  scheduledAt: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Assessment {
  id: string;
  applicationId: string;
  assessorId: string;
  score: number;
  comment: string;
  createdAt: string;
  updatedAt: string;
}

// Applications
export const getApplications = async (): Promise<Application[]> => {
  try {
    const response = await recruitmentApi.get<ApiResponse<Application[]>>('/applications');
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const getApplication = async (id: string): Promise<Application> => {
  try {
    const response = await recruitmentApi.get<ApiResponse<Application>>(`/applications/${id}`);
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const updateApplicationStatus = async (id: string, status: Application['status']): Promise<Application> => {
  try {
    const response = await recruitmentApi.patch<ApiResponse<Application>>(`/applications/${id}/status`, { status });
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

// Interviews
export const getInterviews = async (): Promise<Interview[]> => {
  try {
    const response = await recruitmentApi.get<ApiResponse<Interview[]>>('/interviews');
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const scheduleInterview = async (applicationId: string, scheduledAt: string): Promise<Interview> => {
  try {
    const response = await recruitmentApi.post<ApiResponse<Interview>>('/interviews', {
      applicationId,
      scheduledAt,
    });
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const updateInterviewStatus = async (id: string, status: Interview['status'], notes?: string): Promise<Interview> => {
  try {
    const response = await recruitmentApi.patch<ApiResponse<Interview>>(`/interviews/${id}/status`, {
      status,
      notes,
    });
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

// Assessments
export const createAssessment = async (applicationId: string, score: number, comment: string): Promise<Assessment> => {
  try {
    const response = await recruitmentApi.post<ApiResponse<Assessment>>('/assessments', {
      applicationId,
      score,
      comment,
    });
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const getApplicationAssessments = async (applicationId: string): Promise<Assessment[]> => {
  try {
    const response = await recruitmentApi.get<ApiResponse<Assessment[]>>(`/applications/${applicationId}/assessments`);
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
}; 