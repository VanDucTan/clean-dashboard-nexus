import axios from 'axios';

const API_URL = 'https://api.composio.dev/tools/logout_service';

export const logout = async (token: string) => {
  const response = await axios.post(
    `${API_URL}/auth/logout`,
    {},
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
  return response.data;
}; 