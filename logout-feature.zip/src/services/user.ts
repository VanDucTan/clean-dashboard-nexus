import { userApi, handleApiError, ApiResponse } from '@/lib/axios';

export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  avatar?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UpdateUserRequest {
  name?: string;
  avatar?: string;
}

export const getCurrentUser = async (): Promise<User> => {
  try {
    const response = await userApi.get<ApiResponse<User>>('/users/me');
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const updateCurrentUser = async (data: UpdateUserRequest): Promise<User> => {
  try {
    const response = await userApi.patch<ApiResponse<User>>('/users/me', data);
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const changePassword = async (oldPassword: string, newPassword: string): Promise<void> => {
  try {
    await userApi.post<ApiResponse<void>>('/users/change-password', {
      oldPassword,
      newPassword,
    });
  } catch (error) {
    throw new Error(handleApiError(error));
  }
}; 