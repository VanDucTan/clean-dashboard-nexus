import { authApi, handleApiError, ApiResponse } from '@/lib/axios';

interface LoginResponse {
  token: string;
  user: {
    id: string;
    email: string;
    name: string;
    role: string;
  };
}

interface LoginRequest {
  email: string;
  password: string;
}

export const login = async (data: LoginRequest): Promise<LoginResponse> => {
  try {
    const response = await authApi.post<ApiResponse<LoginResponse>>('/auth/login', data);
    return response.data.data;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const logout = async (): Promise<void> => {
  try {
    await authApi.post<ApiResponse<void>>('/auth/logout');
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const refreshToken = async (): Promise<string> => {
  try {
    const response = await authApi.post<ApiResponse<{ token: string }>>('/auth/refresh');
    return response.data.data.token;
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const forgotPassword = async (email: string): Promise<void> => {
  try {
    await authApi.post<ApiResponse<void>>('/auth/forgot-password', { email });
  } catch (error) {
    throw new Error(handleApiError(error));
  }
};

export const resetPassword = async (token: string, password: string): Promise<void> => {
  try {
    await authApi.post<ApiResponse<void>>('/auth/reset-password', { token, password });
  } catch (error) {
    throw new Error(handleApiError(error));
  }
}; 