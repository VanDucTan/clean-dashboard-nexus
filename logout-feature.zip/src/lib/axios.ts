import axios, { AxiosError, AxiosInstance, InternalAxiosRequestConfig } from 'axios';

// Định nghĩa các API URLs
export const API_URLS = {
  AUTH: 'https://api.composio.dev/tools/auth_service',
  USER: 'https://api.composio.dev/tools/user_service',
  RECRUITMENT: 'https://api.composio.dev/tools/recruitment_service',
  QA: 'https://api.composio.dev/tools/qa_service',
} as const;

// Tạo interface cho response
export interface ApiResponse<T = any> {
  data: T;
  message: string;
  status: number;
}

// Tạo instance axios với config mặc định
const createAxiosInstance = (baseURL: string): AxiosInstance => {
  const instance = axios.create({
    baseURL,
    timeout: 10000,
    headers: {
      'Content-Type': 'application/json',
    },
  });

  // Request interceptor
  instance.interceptors.request.use(
    (config: InternalAxiosRequestConfig) => {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error: AxiosError) => {
      return Promise.reject(error);
    }
  );

  // Response interceptor
  instance.interceptors.response.use(
    (response) => {
      return response;
    },
    (error: AxiosError) => {
      if (error.response?.status === 401) {
        // Token hết hạn hoặc không hợp lệ
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
      return Promise.reject(error);
    }
  );

  return instance;
};

// Tạo các instance cho từng service
export const authApi = createAxiosInstance(API_URLS.AUTH);
export const userApi = createAxiosInstance(API_URLS.USER);
export const recruitmentApi = createAxiosInstance(API_URLS.RECRUITMENT);
export const qaApi = createAxiosInstance(API_URLS.QA);

// Helper function để xử lý lỗi
export const handleApiError = (error: unknown): string => {
  if (axios.isAxiosError(error)) {
    if (error.response) {
      // Lỗi từ server (status code không phải 2xx)
      return error.response.data.message || 'Lỗi từ server';
    } else if (error.request) {
      // Không nhận được response
      return 'Không thể kết nối đến server';
    }
    // Lỗi khi setting up request
    return 'Lỗi khi gửi yêu cầu';
  }
  // Lỗi không xác định
  return 'Đã xảy ra lỗi không xác định';
}; 