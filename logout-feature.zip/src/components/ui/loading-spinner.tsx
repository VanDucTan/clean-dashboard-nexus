import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface LoadingSpinnerProps {
  size?: number;
  className?: string;
}

export const LoadingSpinner = ({ size = 24, className }: LoadingSpinnerProps) => {
  return (
    <Loader2 
      className={cn("animate-spin text-muted-foreground", className)} 
      size={size} 
    />
  );
};

interface LoadingOverlayProps {
  children?: React.ReactNode;
  isLoading: boolean;
  className?: string;
}

export const LoadingOverlay = ({ children, isLoading, className }: LoadingOverlayProps) => {
  if (!isLoading) return <>{children}</>;

  return (
    <div className={cn("relative", className)}>
      {children}
      <div className="absolute inset-0 bg-background/50 flex items-center justify-center backdrop-blur-sm">
        <LoadingSpinner />
      </div>
    </div>
  );
}; 