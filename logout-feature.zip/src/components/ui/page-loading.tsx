import { LoadingSpinner } from "./loading-spinner";

interface PageLoadingProps {
  message?: string;
}

export const PageLoading = ({ message = "Đang tải..." }: PageLoadingProps) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-4 bg-background/50">
      <LoadingSpinner size={32} />
      <p className="text-muted-foreground">{message}</p>
    </div>
  );
}; 